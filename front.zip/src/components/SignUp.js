import React, { useState } from "react";
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBInput,
} from "mdb-react-ui-kit";
import "../App.css";
import { Link, useNavigate } from "react-router-dom"; 
import axios from "axios";


function SignUp() {
  const url = "http://localhost:8088/api/users";
  const navigate = useNavigate();

  const [user, setUser] = useState({
    userName: "",
    email: "",
    age: "", 
    password: "",
  });

  // const handleUserNameChange = (e) => {
  //   setUser({ ...user, userName: e.target.value });
  // };

  // const handleEmailChange = (e) => {
  //   setUser({ ...user, email: e.target.value });
  // };

  // const handleAgeChange = (e) => {
  //   setUser({ ...user, age: e.target.value });
  // };

  // const handlePasswordChange = (e) => {
  //   setUser({ ...user, password: e.target.value });
  // };

  const handleChange = (e) => {
    setUser({ ...user, [e.target.id]: e.target.value });
    // const { id, value } = e.target;
    //      setUser({ ...user, [id]: value });


  };

  const handleSubmit = (e) => {
   e.preventDefault();

    axios
      .post(url, user)
      .then((response) => {
        console.log(response.data);
        alert(response.data.msg);
  
        navigate("/SignIn");
      })

      .catch((error) => {
        if (error.response && error.response.status === 400) {
          // Displaying the server response message in an alert box
          alert(error.response.data.msg);
        } else {
          console.error("There was an error!", error);
        }
      });

  };

  return (
    <MDBContainer
      fluid
      className="d-flex align-items-center justify-content-center bg-image"
  
    >
      <div className="mask gradient-custom-3"></div>
      <MDBCard className="m-5" style={{ maxWidth: "600px" }}>
        <MDBCardBody className="px-5">
          <h2 className="text-uppercase text-center mb-5">Create an account</h2>

          <form onSubmit={handleSubmit}>
            <MDBInput
              wrapperClass="mb-4"
              size="lg"
              type="text"
              placeholder="Enter username"
              onChange={handleChange}
              id="userName"
            />
            <MDBInput
              wrapperClass="mb-4"
              size="lg"
              placeholder="Enter email"
              onChange={handleChange}
              id="email"
            />
            <MDBInput
              wrapperClass="mb-4"
              size="lg"
              placeholder="Enter age"
              type="text"
              onChange={handleChange}
              id="age"
            />
            <MDBInput
              wrapperClass="mb-4"
              size="lg"
              type="password"
              placeholder="Enter password"
              onChange={handleChange}
              id="password"
            />

            <MDBBtn
              className="mb-4 w-100 gradient-custom-4"
              size="lg"
              type="submit"
            >
              Register
            </MDBBtn>
            <div className="text-center">
              <p className="mb-0">
                Already have an account? <Link to="/signIn">Sign in</Link>
              </p>
              <p className="mb-0">
    {/* Already have an account?  */}
    {/* <Link to="/signIn" style={{ textDecoration: 'none' }}>
    <MDBBtn>Sign in</MDBBtn>

    </Link> */}
</p>
            </div>
          </form>
        </MDBCardBody>
      </MDBCard>
    </MDBContainer>
  );
}

export default SignUp;
