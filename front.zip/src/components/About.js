import React from 'react';

function About() {
  return (
    <div className="about-section">
      <h2>Our Mission</h2>
      <p>
        Our mission is simple: to provide innovative and affordable electronic solutions to everyone from tech enthusiasts to professional users. We strive to empower our customers by offering the latest gadgets and electronic components that not only meet but exceed their expectations.
      </p>

      <h2>Our Vision</h2>
      <p>
        We envision a world where access to the latest technology is not a luxury, but a common standard. We aim to lead the electronics sector by setting benchmarks in quality, affordability, and customer satisfaction. We are continually working towards a future where our products and services bring people closer to technology and each other.
      </p>
      <h2>Why Choose Us?</h2>
      <ul>
        <li><strong>Quality and Dependability</strong>: Each product in our catalog has been rigorously tested to ensure it meets our high standards of quality and durability.</li>
        <li><strong>Innovative Solutions</strong>: We stay ahead of the curve, bringing you the latest technological advancements.</li>
        <li><strong>Customer-Centric Service</strong>: Our customers are our top priority. We back our products with exceptional customer service and support, ensuring a seamless shopping experience.</li>
      </ul>

      
    </div>
  );
}

export default About;
