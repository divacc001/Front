import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { Link, NavLink } from "react-router-dom";
import { UserRole } from "./UserRole";
import { useNavigate } from "react-router-dom";


export default function NavigationBar() {
  const linkStyle = {
    textDecoration: "none",
    fontSize: "20px",
    color: "white",
    borderRight: "1px solid white",
    padding: "15px",
    marginLeft: "100px",
  };
  const role = UserRole();
  const navigate=useNavigate()
  const handleSignOut = () => {
    if (window.confirm("Are you sure you want to SignOut")){
      localStorage.removeItem("token"); 
      navigate("/"); 

    }

  };

  return (
    <Navbar bg="dark" data-bs-theme="dark"expand="lg">
      <Container fluid>
      <Nav className="w-100 d-flex justify-content-between"> 
       
         
          <Nav.Link>
            {/* Instead of the 'Link' component you can use a navigation link using the 'NavLink' component from 'react-router-dom'.
     It is a more advanced navigation link. It also navigates to the "/products" route when clicked, but it provides additional features: 
     It allows you to conditionally apply styles based on whether the link is active (i.e., when the current route matches the link's to prop).  */}
            <NavLink
              to="/"
              style={({ isActive }) => {
                return {
                  ...linkStyle,
                  fontWeight: isActive ? "bold" : "",
                  FontSize: isActive ? "25px" : "20px",
                };
              }}
            >
              Home
            </NavLink>
          </Nav.Link>
          <Nav.Link>
            {/* Instead of the 'Link' component you can use a navigation link using the 'NavLink' component from 'react-router-dom'.
     It is a more advanced navigation link. It also navigates to the "/products" route when clicked, but it provides additional features: 
     It allows you to conditionally apply styles based on whether the link is active (i.e., when the current route matches the link's to prop).  */}
            <NavLink
              to="/about"
              style={({ isActive }) => {
                return {
                  ...linkStyle,
                  fontWeight: isActive ? "bold" : "",
                  FontSize: isActive ? "25px" : "20px",
                };
              }}
            >
              About
            </NavLink>
          </Nav.Link>

          <Nav.Link>
            {/* Instead of the 'Link' component you can use a navigation link using the 'NavLink' component from 'react-router-dom'.
     It is a more advanced navigation link. It also navigates to the "/products" route when clicked, but it provides additional features: 
     It allows you to conditionally apply styles based on whether the link is active (i.e., when the current route matches the link's to prop).  */}
            <NavLink
              to="/products"
              style={({ isActive }) => {
                return {
                  ...linkStyle,
                  fontWeight: isActive ? "bold" : "",
                  FontSize: isActive ? "25px" : "20px",
                };
              }}
            >
              Products
            </NavLink>
          </Nav.Link>

          {role === 'admin' && (
            <Nav.Link>
<NavLink
              to="/customers"
              style={({ isActive }) => {
                return {
                  ...linkStyle,
                  fontWeight: isActive ? "bold" : "",
                  FontSize: isActive ? "25px" : "20px",
                };
              }}
            >
              Customers
            </NavLink>            </Nav.Link>
          )}
              {role === 'user' && (
            <Nav.Link>
<NavLink
              to="/profile"
              style={({ isActive }) => {
                return {
                  ...linkStyle,
                  fontWeight: isActive ? "bold" : "",
                  FontSize: isActive ? "25px" : "20px",
                };
              }}
            >
              Profile
            </NavLink>            </Nav.Link>
          )}
        
          <Nav.Link>
            {role ? (
              <Link
                to="/"
                onClick={handleSignOut}
                style={{
                  ...linkStyle,
                  borderRight: "none",
                  border: "3px solid grey",
                  borderRadius: "10px",
                  marginLeft: "190px",
                  padding: "8px",
                }}
              >
                Sign Out
              </Link>
            ) : (
              <Link
                to="/signUp"
                style={{
                  ...linkStyle,
                  borderRight: "none",
                  border: "3px solid grey",
                  borderRadius: "10px",
                  marginLeft: "190px",
                  padding: "8px",
                }}
              >
                SignIn
              </Link>
            )}
          </Nav.Link>
        </Nav>
      </Container>
    </Navbar>
  );
}































































// import React from "react";
// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
// import {  NavLink } from "react-router-dom";
// import Button from "react-bootstrap/Button";

// export default function NavigationBar() {
//   const linkStyle = {
//     textDecoration: "none",
//     fontSize: "20px",
//     color: "white",
//     padding: "15px",
//     display: "flex",
//     flexGrow: 1, // Make each link grow to fill the space

//     alignItems: "center",
//     height: "100%",
//   };

//   const activeLinkStyle = {
//     fontWeight: "bold",
//     fontSize: "22px",
//     borderBottom: "2px solid white",
//   };

//   return (
//     <Navbar bg="dark" variant="dark" expand="lg">
//       <Container>
//         <Nav className="w-100 d-flex justify-content-around">
//           <NavLink to="/" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeLinkStyle } : linkStyle)}>
//             Home
//           </NavLink>
//           <NavLink to="/about" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeLinkStyle } : linkStyle)}>
//             About
//           </NavLink>
//           <NavLink to="/products" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeLinkStyle } : linkStyle)}>
//             Products
//           </NavLink>
//           <NavLink to="/customers" style={({ isActive }) => (isActive ? { ...linkStyle, ...activeLinkStyle } : linkStyle)}>
//             Customers
//           </NavLink>
//           <Button variant="outline-light" href="/signUp" style={{ marginLeft: "auto" }}>
//             SignUp/In
//           </Button>
//         </Nav>
//       </Container>
//     </Navbar>
//   );
// }
