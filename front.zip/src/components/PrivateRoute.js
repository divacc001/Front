import React from "react";
import { Navigate } from "react-router-dom";
import { UserRole} from "./UserRole"; 

function PrivateRoute({ children, allowedRoles }) {
  const role = UserRole();
console.log(role)
  if (role) {
    return (
        <div>  
 {allowedRoles.includes(role) ? children:<Navigate to="/" /> }
        </div>)
  }
  else {
    // No valid token or role, redirect to the Signin page
    return <Navigate to="/signIn" />; 
  }
}

export default PrivateRoute;






































































































// import React from "react";
// import { Navigate } from "react-router-dom";
// import jwt_decode from "jwt-decode";

// function PrivateRoute({ children }) {
//   const token = localStorage.getItem("token");
//   const decodedToken = jwt_decode(token);
//   const userRole = decodedToken.role;
//   return <div>{token && userRole==='admin'? children : <Navigate to="/" />}</div>;
// }

// export default PrivateRoute;
// import React from "react";
// import { Navigate } from "react-router-dom";
// import jwt_decode from "jwt-decode";

// function PrivateRoute({ children }) {
//   const token = localStorage.getItem("token");

//   if (token) {
//     try {
//       const decodedToken = jwt_decode(token);
//       const userRole = decodedToken.role;
//       // Check if the user role is 'admin'
//       return <div>{userRole === "user" ? children : <Navigate to="/" />}</div>;
//     } catch (error) {
//       console.error("Token decoding error:", error);
//       // Handle token decoding errors (e.g., token is malformed)
//       return (
//         <div>
//           <Navigate to="/" />
//         </div>
//       );
//     }
//   } else {
//     // If there's no token, redirect to the home/login page
//     return <Navigate to="/" />;
//   }
// }

// export default PrivateRoute;

// import React from "react";
// import { Navigate } from "react-router-dom";
// import jwt_decode from "jwt-decode";

// function PrivateRoute({ children, allowedRoles }) {
//   const token = localStorage.getItem("token");

//   if (token) {
//     try {
//       const decodedToken = jwt_decode(token);
//       const userRole = decodedToken.role;

//       if (allowedRoles.includes(userRole)) {
//         return <div>{children}</div>;
//       } else {
//         // User role not allowed, redirect to a different page
//         return <Navigate to="/" />;
//       }
//     } catch (error) {
//       console.error("Token decoding error:", error);
//       return <Navigate to="/" />;
//     }
//   } else {
//     // No token, redirect to the login page
//     return <Navigate to="/" />;
//   }
// }

// export default PrivateRoute;
// src/components/PrivateRoute.js (or wherever your PrivateRoute component is located)
// import React from "react";
// import { Navigate } from "react-router-dom";
// import { getUserRoleFromToken } from "../utils/auth"; // Adjust the import path as necessary

// function PrivateRoute({ children, allowedRoles }) {
//   const userRole = getUserRoleFromToken();

//   if (userRole) {
//     return allowedRoles.includes(userRole) ? (
//       <div>{children}</div>
//     ) : (
//       <Navigate to="/unauthorized" /> // Or any other route you prefer for unauthorized access
//     );
//   } else {
//     // No valid token or role, redirect to the login page
//     return <Navigate to="/login" />; // Adjust the redirect route as needed
//   }
// }

// export default PrivateRoute;
// src/components/PrivateRoute.js (or wherever your PrivateRoute component is located)